# -*- coding: UTF-8 -*-
from __future__ import unicode_literals

default_app_config = 'demo_app.apps.DemoAppConfig'